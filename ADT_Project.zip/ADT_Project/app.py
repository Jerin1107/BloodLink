from flask import Flask,render_template,request,flash,session
from flaskext.mysql import MySQL
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__, template_folder='templates')
app.secret_key = 'jerin'

mysql = MySQL()
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = 'Kadamattam@1107'
app.config['MYSQL_DATABASE_DB'] = 'bbms'
app.config['MYSQL_DATABASE_HOST'] = 'localhost'

mysql.init_app(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/home')
def home():
    return render_template('index.html')

@app.route('/signup',methods = ['POST', 'GET'])
def signUp():
    if request.method == 'POST':
        name        = request.form['name']
        phoneNumber = request.form['phoneNumber']
        email       = request.form['email']
        bloodType   = request.form['bloodType']
        dateOfBirth = request.form['dateOfBirth']
        gender      = request.form['gender']
        userType    = request.form['userType']
        password1   = request.form['password1']
        password2   = request.form['password2']

        passwd = generate_password_hash(password1, method='sha256')

        #cursor = mysql.connection.cursor()
        cursor = mysql.get_db().cursor()

        cursor.execute('SELECT * FROM BloodLinkUsers WHERE email = %s AND password = %s', (email, check_password_hash(password1,password1)))
        account = cursor.fetchone()

        if account:
            flash('Account already exists!', category='error')
        elif password1 != password2:
            flash('Passwords don\'t match.', category='error')
        else:
            cursor.execute('''INSERT INTO BloodLinkUsers (Email,Password,UserType)
                                        VALUES(%s,%s,%s) '''
                           , (email,generate_password_hash(passwd),userType))

            #mysql.connection.commit()
            mysql.get_db().commit()

            cursor.execute('SELECT * FROM BloodLinkUsers WHERE email = %s AND password = %s', (email, check_password_hash(password1,password1)))
            account = cursor.fetchone()
            #print(account)
            if userType == 'Donor':
                cursor.execute('''INSERT INTO DONOR (DonorId,Name,Contact,Email,BloodType,DOB,Gender,Address)
                                VALUES(%s,%s,%s,%s,%s,%s,%s,%s) '''
                               ,(account[0],name,phoneNumber,email,bloodType,dateOfBirth,gender,''))
            elif userType == 'Recipient':
                cursor.execute('''INSERT INTO RECIPIENT (RecipientId,Name,Contact,Email,RequiredBloodType,DOB,Gender,Address)
                                            VALUES(%s,%s,%s,%s,%s,%s,%s,%s) '''
                               , (account[0],name, phoneNumber, email,bloodType,dateOfBirth, gender, ''))
            #mysql.connection.commit()
            mysql.get_db().commit()
            cursor.close()


    return render_template('signup.html')

@app.route('/login',methods=['GET', 'POST'])
def login():
    if request.method == 'POST' and 'email' in request.form and 'password' in request.form:
        # Create variables for easy access
        email = request.form['email']
        password = request.form['password']
        #cursor = mysql.connection.cursor()
        cursor = mysql.get_db().cursor()
        cursor.execute('SELECT * FROM BloodLinkUsers WHERE email = %s AND password = %s', (email, check_password_hash(password,password)))
        account = cursor.fetchone()
        print(account)
        if account:
            print("inside if")
            # Create session data, we can access this data in other routes
            session['loggedin'] = True
            print("inside if 2")
            session['id'] = account[0]
            session['email'] = account[1]
            session['userType'] = account[3]
            flash('Logged in successfully!',category='success')
            if account[3] == 'Employee':
                return  render_template('adminBase.html')
            return  render_template('index.html')
        else:
            print("inside else")
            flash('Incorrect username/password!',category='error')
    return render_template('login.html')

@app.route('/logout',methods=['GET', 'POST'])
def logout():
    session.pop('loggedin', None)
    session.pop('id', None)
    session.pop('username', None)
    session.pop('userType',None)
    flash('Logged out successfully!',category='success')
    return render_template('index.html')

@app.route('/contactUs',methods=['GET', 'POST'])
def contactUs():
    return render_template('contactUs.html')


@app.route('/adminBase',methods=['GET', 'POST'])
def adminBase():
    return render_template('adminBase.html')

@app.route('/adminDonor',methods=['GET', 'POST'])
def adminDonor():
    #cursor = mysql.connection.cursor()
    cursor = mysql.get_db().cursor()
    cursor.execute('SELECT * FROM Donor')
    donorData = cursor.fetchall()
    return render_template('adminDonor.html',donorData=donorData)

@app.route('/aboutUs',methods=['GET', 'POST'])
def aboutUs():
    return render_template('aboutUs.html')

@app.route('/inventory',methods=['GET', 'POST'])
def inventory():
    cursor = mysql.get_db().cursor()
    cursor.execute('SELECT * FROM ViewInventoryV2')
    inventoryData = cursor.fetchall()
    print(inventoryData)
    return render_template('inventory.html', inventoryData=inventoryData)

@app.route('/book_appointment', methods=['GET', 'POST'])
def book_appointment():
    if request.method == 'POST':
        # bbid = request.form['bbid']
        bbname = request.form['bbname']
        date = request.form['date']
        time = request.form['time']
        print("the data from server is: "+bbname)
        bbid, bbn = bbname.split(", ")[0][1:], bbname.split(", ")[1][:-1]
        bbn = bbn[:-1].replace("'", "")
        print(bbid)
        print(bbname)
        # Save the appointment details to the MySQL database
        #USERTYPE = session['USERTYPE']
        userId = '2'
        USERTYPE = 'Donor'
        cursor = mysql.get_db().cursor()
        if(USERTYPE == 'Donor'):
            cursor.execute('INSERT INTO donorAppointment (DonorId,BloodBankId,BloodBankName, Date, Time) VALUES (%s, %s, %s, %s,%s)' ,(userId,bbid, bbn, date, time))
        elif (USERTYPE == 'Recipient'):
            cursor.execute('INSERT INTO recipientAppointment (RecipientId,BloodBankId,BloodBankName, Date, Time) VALUES (%s, %s, %s, %s,%s)' ,(userId,bbid, bbn, date, time))
        mysql.get_db().commit()
        cursor.close()
        # Redirect to a success page
        return render_template('appointment.html')
    else:
        # Fetch data from the MySQL database to populate the dropdown list
        cursor = mysql.get_db().cursor()
        cursor.execute('SELECT BloodBankId, Name FROM BloodBank;')
        bloodbank_data = cursor.fetchall()
        bloodbanks = [[row[0], row[1]] for row in bloodbank_data]
        # print(bloodbanks[0])
        # bloodbankIDs = [row[0] for row in bloodbank_data]
        # print(bloodbankIDs)
        # Render the HTML page and pass the data to the template
        search_query = request.args.get('search')
        if search_query:
            # Filter the bloodbanks list based on the search query
            bloodbanks = [row for row in bloodbank_data if search_query.lower() in row[1].lower()]
        # Render the HTML page and pass the data to the template
        return render_template('appointment.html', bloodbanks=bloodbanks, search_query=search_query)
        # return render_template('appointment.html', bloodbanks=bloodbanks)

if __name__ == '__main__':
    app.run(debug=True)
